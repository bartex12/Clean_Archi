package ru.geekbrains.arch.homework.network;

public interface ApiKeyProvider {
    String getApiKey();
}
