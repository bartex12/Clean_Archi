package ru.geekbrains.arch.homework.interactor.appstart;

import io.reactivex.Completable;

public interface AppStartInteractor {
    Completable countAppStart();
}
