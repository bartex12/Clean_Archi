package ru.geekbrains.arch.homework.util.resources;

import androidx.annotation.StringRes;

public interface ResourceManager {

    String getString(@StringRes int id);

}
