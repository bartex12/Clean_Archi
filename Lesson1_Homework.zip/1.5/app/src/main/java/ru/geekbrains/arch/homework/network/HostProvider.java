package ru.geekbrains.arch.homework.network;


public interface HostProvider {
    String getHostUrl();
}
